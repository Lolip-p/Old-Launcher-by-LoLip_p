import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
//import 'package:url_launcher/url_launcher.dart';
import 'package:external_app_launcher/external_app_launcher.dart';





void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Скрыть строку состояния системы и панель навигации
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive,
        overlays: [SystemUiOverlay.top, SystemUiOverlay.bottom]);

    return MaterialApp(
      title: 'Пользовательское приложение для строки состояния',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        splashColor: Colors.transparent,
        highlightColor: Colors.transparent,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String _batteryLevel = 'Неизвестно';
  Image  _batteryIcon = Image.asset('assets/Bat_full.ico', width: 25, height: 25); // Значок батареи по умолчанию

  String _currentTime = '';
  Timer? _timer;


  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }


  void _startTimer() {
    // Таймер, чтобы скрывать системный интерфейс каждые 5 секунд.
    _timer = Timer.periodic(const Duration(seconds: 5), (timer) {
      _hideSystemUI();
    });
  }


  void _hideSystemUI() {
    // Скрыть строку состояния и панель навигации
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive, overlays: []);
  }


  @override
  void initState() {
    super.initState();
    _startTimer();
    // Инициализировать уровень заряда батареи
    _getBatteryLevel();

    // Периодически обновляйте уровень заряда батареи
    Timer.periodic(const Duration(seconds: 30), (timer) {
      _getBatteryLevel();
    });

    // Обновлять текущее время каждую секунду
    Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _currentTime = '${DateTime.now().hour}:${DateTime.now().minute.toString().padLeft(2, '0')}';
      });
    });
  }



  // Установка батареи
  Future<void> _getBatteryLevel() async {
    const platform = MethodChannel('samples.flutter.dev/battery');
    try {
      final batteryLevel = await platform.invokeMethod('getBatteryLevel');
      setState(() {
        _batteryLevel = batteryLevel.toString();
        _updateBatteryIcon(int.parse(_batteryLevel));
      });
    } on PlatformException catch (e) {
      setState(() {
        _batteryLevel = 'Не удалось получить уровень заряда батареи: ${e.message}.';
      });
    }
  }



  // Метод смены иконок при разном заряде
  void _updateBatteryIcon(int batteryLevel) {
    if (batteryLevel >= 80) {
      _batteryIcon = Image.asset('assets/Bat_full.ico', width: 25, height: 25);
    } else if (batteryLevel >= 60) {
      _batteryIcon = Image.asset('assets/Bat_f4.ico', width: 25, height: 25);
    } else if (batteryLevel >= 40) {
      _batteryIcon = Image.asset('assets/Bat_f3.ico', width: 25, height: 25);
    } else if (batteryLevel >= 20) {
      _batteryIcon = Image.asset('assets/Bat_f2.ico', width: 25, height: 25);
    } else if (batteryLevel >= 0) {
      _batteryIcon = Image.asset('assets/Bat_f1.ico', width: 25, height: 25);
    } else {
      _batteryIcon = Image.asset('assets/Bat_full.ico', width: 25, height: 25);
    }
  }



  // Методы срабатывающие при клике на кнопки
  void _launchSms() async {
    String packageName = "com.android.mms";
    await LaunchApp.openApp(
        androidPackageName: packageName,
        openStore: false
    );
  }
  void _launchmagazine() async {
    String packageName = "com.android.telephony";
    await LaunchApp.openApp(
        androidPackageName: packageName,
        openStore: false
    );
  }
  void _launchSettings() async {
    String packageName = "com.android.settings";
    await LaunchApp.openApp(
        androidPackageName: packageName,
        openStore: false
    );
  }
  void _launchcontacts() async {
    String packageName = "com.android.dialer";
    await LaunchApp.openApp(
        androidPackageName: packageName,
        openStore: false
    );
  }
  void _launchcalendar() async {
    String packageName = "com.android.calendar";
    await LaunchApp.openApp(
        androidPackageName: packageName,
        openStore: false
    );
  }
  void _launchFiles() async {
    String packageName = "com.google.android.nbu.files";
    await LaunchApp.openApp(
        androidPackageName: packageName,
        openStore: false
    );
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(''),
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/background_image3.png'), // Установить фон
                fit: BoxFit.cover,
              ),
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[



                  // Пользовательская строка состояния
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    color: Colors.black.withOpacity(0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[



                        const Stack(
                          alignment: Alignment.center,
                          children: [

                            ImageIcon(
                              AssetImage('assets/no_signal.ico'),
                              color: Colors.white,
                              size: 16, // Отрегулируйте размер значка Wi-Fi
                            ), // Отображение значка качества соединения
                          ],
                        ),



                        // Почему закоментил уже не помню
                        /*
                        Stack(
                          alignment: Alignment.center,
                          children: [
                            Text(
                              '$_currentTime',
                              style: TextStyle(
                                color: Colors.transparent,
                                fontSize: 18, // Adjust the size of the time text
                                shadows: [
                                  Shadow(
                                    blurRadius: 2,
                                    color: Colors.black,
                                    offset: Offset(1, 1),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              '$_currentTime',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18, // Adjust the size of the time text
                              ),
                            ),
                          ],
                        ),
                        */



                        Row(
                          children: <Widget>[
                            _batteryIcon,
                          ],
                        ),



                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),



          // Время
          Center(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 195),
              child: Align(
                alignment: Alignment.center,
                child: Text(
                  _currentTime,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 75,
                    shadows: [
                      Shadow(
                        blurRadius: 2,
                        color: Colors.black,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),



          // Сообщения
          Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 190, right: 0),
              child: Column( // Добавлен виджет «Столбец» для вертикального расположения изображения и текста.
                children: [
                  AbsorbPointer(
                    absorbing: true, // Установите значение true, чтобы отключить сенсорный экран.
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        focusColor: const Color.fromARGB(65, 0, 0, 0),
                        onTap: _launchSms, // Метод который будет срабатывать при клике
                        borderRadius: BorderRadius.circular(8), // Отрегулируйте радиус границы
                        child: Container(
                          padding: const EdgeInsets.all(8), // Добавьте отступ для значка
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(0, 0, 0, 0),
                            borderRadius: BorderRadius.circular(8), // Отрегулируйте радиус границы
                          ),
                          child: Image.asset(
                            'assets/sms.ico', // Заменить иконку
                            width: 60, // Отрегулируйте ширину в соответствии с размером вашего значка.
                            height: 60, // Отрегулируйте высоту в соответствии с размером вашего значка.
                          ),
                        ),
                      ),
                    ),
                  ),
                  const Text(
                    'Сообщения', // Замените «Ваш текст здесь» на желаемый текст.
                    style: TextStyle(
                      shadows: [
                        Shadow(
                          blurRadius: 2,
                          color: Colors.black,
                          offset: Offset(1, 1),
                        ),
                      ],
                      color: Colors.white,
                      fontSize: 16, // Отрегулируйте размер шрифта по мере необходимости
                    ),
                  ),
                ],
              ),
            ),
          ),



          // Настройки
          Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 190, left: 200),
              child: Column(
                children: [
                  AbsorbPointer(
                    absorbing: true,
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        focusColor: const Color.fromARGB(65, 0, 0, 0),
                        onTap: _launchSettings,
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(0, 0, 0, 0),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Image.asset(
                            'assets/settings.ico',
                            width: 60,
                            height: 60,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const Text(
                    'Настройки',
                    style: TextStyle(
                      shadows: [
                        Shadow(
                          blurRadius: 2,
                          color: Colors.black,
                          offset: Offset(1, 1),
                        ),
                      ],
                      color: Colors.white,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Контакты
          Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 190, right: 200),
              child: Column(
                children: [
                  AbsorbPointer(
                    absorbing: true,
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        focusColor: const Color.fromARGB(65, 0, 0, 0),
                        onTap: _launchcontacts,
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(0, 0, 0, 0),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Image.asset(
                            'assets/cont.ico',
                            width: 60,
                            height: 60,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const Text(
                    'Контакты',
                    style: TextStyle(
                      shadows: [
                        Shadow(
                          blurRadius: 2,
                          color: Colors.black,
                          offset: Offset(1, 1),
                        ),
                      ],
                      color: Colors.white,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Журналы
          Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 300, left: 0),
              child: Column(
                children: [
                  AbsorbPointer(
                    absorbing: true,
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        focusColor: const Color.fromARGB(65, 0, 0, 0),
                        onTap: _launchmagazine,
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(0, 0, 0, 0),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Image.asset(
                            'assets/jir.ico',
                            width: 60,
                            height: 60,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const Text(
                    'Журналы',
                    style: TextStyle(
                      shadows: [
                        Shadow(
                          blurRadius: 2,
                          color: Colors.black,
                          offset: Offset(1, 1),
                        ),
                      ],
                      color: Colors.white,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Файлы
          Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 300, left: 200),
              child: Column(
                children: [
                  AbsorbPointer(
                    absorbing: true,
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        focusColor: const Color.fromARGB(65, 0, 0, 0),
                        onTap: _launchFiles,
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(0, 0, 0, 0),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Image.asset(
                            'assets/files.ico',
                            width: 60,
                            height: 60,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const Text(
                    'Файлы',
                    style: TextStyle(
                      shadows: [
                        Shadow(
                          blurRadius: 2,
                          color: Colors.black,
                          offset: Offset(1, 1),
                        ),
                      ],
                      color: Colors.white,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Календарь
          Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 300, right: 200),
              child: Column(
                children: [
                  AbsorbPointer(
                    absorbing: true,
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        focusColor: const Color.fromARGB(65, 0, 0, 0),
                        onTap: _launchcalendar,
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(0, 0, 0, 0),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Image.asset(
                            'assets/kalin.ico',
                            width: 60,
                            height: 60,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const Text(
                    'Календарь',
                    style: TextStyle(
                      shadows: [
                        Shadow(
                          blurRadius: 2,
                          color: Colors.black,
                          offset: Offset(1, 1),
                        ),
                      ],
                      color: Colors.white,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
          ),



        ],
      ),
    );
  }
}
